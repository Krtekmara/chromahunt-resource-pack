ChromaHunt bundled character animations
========================================

This pack contains the RealisticMinecraft articulated player models and shaders
integrated directly into ChromaHunt. Do not install the separate
RealisticMinecraft plugin JAR.

The server enables these models for configured ChromaHunt roles. By default that
means seekers and players in the lobby/waiting phases. The real vanilla body is
masked per viewer; the owner's own vanilla body and custom display are both
hidden to prevent the transparent third-person ghost.

Dynamic player-skin rendering is based on Stable Player Display (CC0). See
LICENSE-stable-player-display.txt.
