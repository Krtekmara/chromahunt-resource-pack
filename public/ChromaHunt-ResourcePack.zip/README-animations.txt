ChromaHunt bundled RealisticMinecraft animations
================================================

This resource pack combines ChromaHunt 1.2.5 with the supplied
RealisticMinecraft 0.6.7 character models, textures and version-specific
shader overlays. The standalone RealisticMinecraft plugin must not be installed;
its animation engine is bundled directly into ChromaHunt.jar.

Default role scope
------------------
- Arena WAITING / COUNTDOWN players: animations and emote menu enabled
- SEEKER during active play: animations and emote menu enabled
- Outside the arena, HIDER, SPECTATOR and results: disabled

The owner's normal vanilla body remains visible for eligible animation roles.
Only an actively disguised hider has their translucent vanilla self-body hidden.

Dynamic player-skin rendering is based on Stable Player Display (CC0). See
LICENSE-stable-player-display.txt.
