ChromaHunt bundled RealisticMinecraft animations
================================================

This resource pack combines ChromaHunt 1.2.5 with the supplied
RealisticMinecraft 0.6.7 character models, textures and version-specific
shader overlays. The standalone RealisticMinecraft plugin must not be installed;
its animation engine is bundled directly into ChromaHunt.jar.

Default role scope
------------------
- Arena WAITING / COUNTDOWN players: animations and emote menu enabled
- SEEKER during active play: animations and emote menu enabled
- Outside the arena, HIDER, SPECTATOR and results: disabled

Eligible players see their own articulated rig in third person as well as other
players' rigs. Their native body is masked only for the matching viewer; this is
not a global vanish. Only an actively disguised hider uses the separate hider
self-body concealment.

The climbing pose is bridged to ChromaHunt's custom wall and ceiling attachment
states as well as vanilla ladders and vines. Walking, sprinting, swimming,
gliding and the remaining RealisticMinecraft movement poses stay available.

The resource pack adds a clean five-segment radial emote-wheel glyph. Its pose
icons are part of one texture, so no barrier or vanilla item icons cover the
wheel. A six-row menu keeps it clear of the player's inventory. A vanilla Java
client sends the swap-hands key press to the server but does not send its key-up
event, so server-only control is press/toggle: F opens the wheel and selection,
Esc, or F again closes it. Exact hold-and-release control requires a client mod.

The player shaders distinguish both half and full blink states, use skin pixels
for the eyelids, and discard only the custom head that is too close to the local
first-person camera. This prevents the giant face overlay without removing the
third-person animated character. Unused cosmetic, cape and unsupported display
layer assets were pruned; the animation models and supported version overlays
remain.

Dynamic player-skin rendering is based on Stable Player Display (CC0). See
LICENSE-stable-player-display.txt.
