#version 150
#moj_import <minecraft:fog.glsl>
#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define RM_PLAYER_DISPLAY 1
#endif

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
#ifdef RM_PLAYER_DISPLAY
in vec2 rmTexCoordUnder;
in float rmPart;
in float rmCameraDistance;

void rm_fix_outer_layer(inout vec4 color, vec2 underUv, float partValue, float distanceValue) {
    // The special head renderer draws an outer hat cube too. Cape profiles use
    // only the inner cube, so discard the duplicate outer shell.
    if (partValue < -999.0) discard;

    // Restored 0.6.4 algorithm: close exactly the standard base-eye pixels and
    // matching hat-layer pixels with the skin row directly above them.
    bool halfBlink = abs(partValue + 11.0) < 0.1;
    bool fullBlink = abs(partValue + 13.0) < 0.1;
    bool headPart = abs(partValue) < 0.1 || halfBlink || fullBlink;
    if (headPart && rmCameraDistance < 0.72) discard;

    if (halfBlink || fullBlink) {
        ivec2 pixel = ivec2(floor(texCoord0 * 64.0));
        bool closedRow = fullBlink ? (pixel.y >= 12 && pixel.y <= 13) : pixel.y == 13;
        bool baseEye = closedRow
            && ((pixel.x >= 10 && pixel.x <= 11) || (pixel.x >= 14 && pixel.x <= 15));
        bool outerEye = closedRow
            && ((pixel.x >= 42 && pixel.x <= 43) || (pixel.x >= 46 && pixel.x <= 47));
        if (baseEye || outerEye) {
            vec2 lidUv = (vec2(float(pixel.x), 11.5)) / 64.0;
            vec4 lid = texture(Sampler0, lidUv);
            color.rgb = lid.rgb;
            color.a = max(color.a, lid.a);
        }
    }

    if (partValue > 1.0 - 1e-6 && color.a < 1.0) {
        const float RM_MINALPHA = 0.25;
        const float RM_FADEBIAS = 8.0;
        const float RM_FADERANGE = 12.0;
        const mat4 rm_bayer4 = mat4(
             0.0/16.0,  8.0/16.0,  2.0/16.0, 10.0/16.0,
            12.0/16.0,  4.0/16.0, 14.0/16.0,  6.0/16.0,
             3.0/16.0, 11.0/16.0,  1.0/16.0,  9.0/16.0,
            15.0/16.0,  7.0/16.0, 13.0/16.0,  5.0/16.0
        );
        color.a = max(color.a, RM_MINALPHA);
        vec3 underCol = texture(Sampler0, underUv).rgb;
        vec3 trueMix = mix(underCol, color.rgb, color.a);
        float fade = mix(color.a, 1.0, clamp((distanceValue - RM_FADEBIAS) / (RM_FADERANGE - RM_FADEBIAS), 0.0, 1.0));
        color = vec4((trueMix - (1.0 - fade) * underCol) / fade, fade);
        if (color.a < rm_bayer4[int(gl_FragCoord.x) % 4][int(gl_FragCoord.y) % 4] + (0.5 / 16.0)) discard;
        color.a = 1.0;
    }
}

#endif
out vec4 fragColor;
void main() {
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
    color *= vertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif
    color = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
#ifdef RM_PLAYER_DISPLAY
    rm_fix_outer_layer(color, rmTexCoordUnder, rmPart, vertexDistance);
#endif
    fragColor = color;
}
