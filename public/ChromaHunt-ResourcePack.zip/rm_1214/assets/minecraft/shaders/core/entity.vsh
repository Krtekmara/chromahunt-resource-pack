#version 150
#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define RM_PLAYER_DISPLAY 1
#endif

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat4 TextureMat;
uniform int FogShape;
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;
#ifdef RM_PLAYER_DISPLAY
uniform sampler2D Sampler0;
out vec2 rmTexCoordUnder;
out float rmPart;
out float rmCameraDistance;

#define RM_SPACING 1024.0
#define RM_MAXRANGE (0.5 * RM_SPACING)
#define RM_SKINRES 64
#define RM_FACERES 8
#define RM_SLIMCHECK0 vec2(54.0 / float(RM_SKINRES), 20.0 / float(RM_SKINRES))
#define RM_SLIMCHECK1 vec2(55.0 / float(RM_SKINRES), 20.0 / float(RM_SKINRES))

const vec4[] rm_subuvs = vec4[](
    vec4(4.0,0.0,8.0,4.0), vec4(8.0,0.0,12.0,4.0), vec4(0.0,4.0,4.0,16.0), vec4(4.0,4.0,8.0,16.0), vec4(8.0,4.0,12.0,16.0), vec4(12.0,4.0,16.0,16.0),
    vec4(4.0,0.0,7.0,4.0), vec4(7.0,0.0,10.0,4.0), vec4(0.0,4.0,4.0,16.0), vec4(4.0,4.0,7.0,16.0), vec4(7.0,4.0,11.0,16.0), vec4(11.0,4.0,14.0,16.0),
    vec4(4.0,0.0,12.0,4.0), vec4(12.0,0.0,20.0,4.0), vec4(0.0,4.0,4.0,16.0), vec4(4.0,4.0,12.0,16.0), vec4(12.0,4.0,16.0,16.0), vec4(16.0,4.0,24.0,16.0)
);
const vec2[] rm_origins = vec2[](
    vec2(40.0,16.0), vec2(40.0,32.0),
    vec2(32.0,48.0), vec2(48.0,48.0),
    vec2(16.0,16.0), vec2(16.0,32.0),
    vec2(0.0,16.0), vec2(0.0,32.0),
    vec2(16.0,48.0), vec2(0.0,48.0)
);
const int[] rm_faceremap = int[](0,0,1,1,2,3,4,5);
const vec4[] rm_capeuvs = vec4[](
    vec4(1.0,0.0,11.0,1.0), vec4(11.0,0.0,21.0,1.0),
    vec4(0.0,1.0,1.0,17.0), vec4(12.0,1.0,22.0,17.0),
    vec4(11.0,1.0,12.0,17.0), vec4(1.0,1.0,11.0,17.0)
);

void rm_remap_player_display(inout vec3 pos, inout vec2 uv, out vec2 underUv, out float partValue) {
    underUv = vec2(0.0);
    partValue = 0.0;
    ivec2 dim = textureSize(Sampler0, 0);
    int rawPartId = -int((pos.y - RM_MAXRANGE) / RM_SPACING);

    // Blink frames keep the normal head UVs and only mark the eye pixels for
    // the fragment shader. The large transform offset is restored here.
    if ((rawPartId == 11 || rawPartId == 13) && dim.x == RM_SKINRES && dim.y == RM_SKINRES) {
        // Exact two-tick blink used by 0.6.4: keep the normal skin UV and mark
        // only the player's real eye pixels for the fragment shader.
        partValue = -float(rawPartId);
        pos.y += RM_SPACING * rawPartId;
        return;
    }

    // A cape URL is exposed as a synthetic player-head skin. Depending on the
    // client it arrives as 64x32 or is legacy-expanded to 64x64; the original
    // 10x16 cape rectangle remains in the upper-left area in both cases.
    if (rawPartId == 12 && dim.x == RM_SKINRES && dim.y >= 32) {
        int outerLayer = (gl_VertexID / 24) % 2;
        partValue = outerLayer == 0 ? -12.0 : -1000.0;
        int vertexId = gl_VertexID % 4;
        int faceId = (gl_VertexID % 24) / 4;
        ivec2 faceTmp = ivec2(round(uv * RM_SKINRES));
        if ((faceId != 1 && vertexId >= 2) || (faceId == 1 && vertexId <= 1)) faceTmp.y -= RM_FACERES;
        if (vertexId == 0 || vertexId == 3) faceTmp.x -= RM_FACERES;
        faceTmp /= RM_FACERES;
        faceId = rm_faceremap[(faceTmp.x % 4) + 4 * faceTmp.y];
        vec4 subuv = rm_capeuvs[faceId];
        vec2 offset;
        if (faceId == 1) {
            if (vertexId == 0) offset = subuv.zw;
            else if (vertexId == 1) offset = subuv.xw;
            else if (vertexId == 2) offset = subuv.xy;
            else offset = subuv.zy;
        } else {
            if (vertexId == 0) offset = subuv.zy;
            else if (vertexId == 1) offset = subuv.xy;
            else if (vertexId == 2) offset = subuv.xw;
            else offset = subuv.zw;
        }
        uv = offset / vec2(float(dim.x), float(dim.y));
        pos.y += RM_SPACING * rawPartId;
        return;
    }

    if (dim.x != RM_SKINRES || dim.y != RM_SKINRES) return;

    partValue = float(rawPartId);
    if (rawPartId == 0) return;

    int partId = rawPartId - 1;
    vec4 samp1 = texture(Sampler0, RM_SLIMCHECK0);
    vec4 samp2 = texture(Sampler0, RM_SLIMCHECK1);
    bool slim = samp1.a == 0.0 || (((samp1.r+samp1.g+samp1.b)==0.0) && ((samp2.r+samp2.g+samp2.b)==0.0) && samp1.a==1.0 && samp2.a==1.0);

    int partIdMod = partId % 5;
    int outerLayer = (gl_VertexID / 24) % 2;
    int vertexId = gl_VertexID % 4;
    int faceId = (gl_VertexID % 24) / 4;
    ivec2 faceTmp = ivec2(round(uv * RM_SKINRES));

    vec2 uvOut = rm_origins[2 * partIdMod + outerLayer];
    vec2 uvUnder = rm_origins[2 * partIdMod];

    if ((faceId != 1 && vertexId >= 2) || (faceId == 1 && vertexId <= 1)) faceTmp.y -= RM_FACERES;
    if (vertexId == 0 || vertexId == 3) faceTmp.x -= RM_FACERES;
    faceTmp /= RM_FACERES;
    faceId = rm_faceremap[(faceTmp.x % 4) + 4 * faceTmp.y];

    int subIndex = faceId;
    if (slim && (partIdMod == 0 || partIdMod == 1)) subIndex += 6;
    else if (partIdMod == 2) subIndex += 12;
    vec4 subuv = rm_subuvs[subIndex];

    // Split model: upper and lower limb halves each consume six skin pixels.
    if (faceId >= 2) {
        subuv.w -= 6.0;
        if (partId >= 5) subuv.yw += 6.0;
    }

    vec2 offset;
    if (faceId == 1) {
        if (vertexId == 0) offset = subuv.zw;
        else if (vertexId == 1) offset = subuv.xw;
        else if (vertexId == 2) offset = subuv.xy;
        else offset = subuv.zy;
    } else {
        if (vertexId == 0) offset = subuv.zy;
        else if (vertexId == 1) offset = subuv.xy;
        else if (vertexId == 2) offset = subuv.xw;
        else offset = subuv.zw;
    }

    uv = (uvOut + offset) / float(RM_SKINRES);
    underUv = (uvUnder + offset) / float(RM_SKINRES);
    pos.y += RM_SPACING * rawPartId;
}

#endif
out float vertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
void main() {
    vec3 pos = Position;
    vec2 uv = UV0;
#ifdef RM_PLAYER_DISPLAY
    rm_remap_player_display(pos, uv, rmTexCoordUnder, rmPart);
    rmCameraDistance = length((ModelViewMat * vec4(pos, 1.0)).xyz);
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    vertexDistance = fog_distance(pos, FogShape);
#ifdef NO_CARDINAL_LIGHTING
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    texCoord0 = uv;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
